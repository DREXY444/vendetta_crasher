// ©AiiSigma

module.exports = {
  domain: "https://mugiwara.panel.twilightparadox.com",
  port: "2011"
};

// BOT TOKEN SAMA ID OWNER ADA DI index.js hal 26-27